// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

contract VotingSimple {
    string public title = "Consulta";
    string[2] public options = ["Si", "No"]; // index 0..1

    mapping(bytes32 => bool) public registered;
    mapping(bytes32 => uint8) private voteOf; // 0..1 válido sólo si hasVoted[voterHash]=true
    mapping(bytes32 => bool) private hasVoted;
    uint256[2] public results; // recuento por opción

    event VoterRegistered(bytes32 indexed voterHash);
    event VoteCast(bytes32 indexed voterHash, uint8 optionIndex, bool changed);

    // Registro por hash (el propio votante lo invoca con su hash)
    function registerVoter(bytes32 voterHash) external {
        require(!registered[voterHash], "already");
        registered[voterHash] = true;
        emit VoterRegistered(voterHash);
    }

    // Voto/actualización (último voto cuenta)
    function castVote(bytes32 voterHash, uint8 optionIndex) external {
        require(registered[voterHash], "not registered");
        require(optionIndex < 2, "bad option");

        if (hasVoted[voterHash]) {
            uint8 prev = voteOf[voterHash];
            results[prev] -= 1;
        }
        voteOf[voterHash] = optionIndex;
        hasVoted[voterHash] = true;
        results[optionIndex] += 1;

        emit VoteCast(voterHash, optionIndex, true);
    }

    function getVote(
        bytes32 voterHash
    )
        external
        view
        returns (bool _registered, bool _hasVoted, uint8 optionIndex)
    {
        _registered = registered[voterHash];
        _hasVoted = hasVoted[voterHash];
        optionIndex = voteOf[voterHash];
    }

    function tally() external view returns (uint256 yes, uint256 no) {
        return (results[0], results[1]);
    }
}
