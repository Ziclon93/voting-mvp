import { expect } from "chai";
import hre from "hardhat";
import { loadFixture } from "@nomicfoundation/hardhat-network-helpers";

const h = (ethers: any, s: string) => ethers.keccak256(ethers.toUtf8Bytes(s));

describe("VotingSimple", () => {
  async function deployFixture(connection: any) {
    const F = await connection.ethers.getContractFactory("VotingSimple");
    const c = await F.deploy();
    await c.waitForDeployment();
    return { c, ethers: connection.ethers };
  }

  it("registro, voto y cambio de voto", async () => {
    const connection = await hre.network.connect();
    const { c, ethers } = await loadFixture(deployFixture.bind(null, connection));

    const vh = h(ethers, "dni|fecha|secreto");
    await (await c.registerVoter(vh)).wait();
    await (await c.castVote(vh, 0)).wait(); // Si
    await (await c.castVote(vh, 1)).wait(); // Cambio a No

    const [yes, no] = await c.tally();
    expect(yes).to.equal(0n);
    expect(no).to.equal(1n);
  });
});
