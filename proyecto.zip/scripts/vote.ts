import hre from "hardhat";

async function main() {
  const connection = await hre.network.connect();
  const { ethers } = connection;

  const ADDR = process.env.CONTRACT!;
  const h = (s: string) => ethers.keccak256(ethers.toUtf8Bytes(s));

  const c = await ethers.getContractAt("VotingSimple", ADDR);
  const voterHash = h(process.env.VOTER!);
  const opt = parseInt(process.env.OPT || "0", 10);

  const tx = await c.castVote(voterHash, opt);
  await tx.wait();
  console.log("Voted:", voterHash, "->", opt);
}

main().catch((e) => { console.error(e); process.exit(1); });
