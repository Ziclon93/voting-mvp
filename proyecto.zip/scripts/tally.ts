import hre from "hardhat";

async function main() {
  const connection = await hre.network.connect();
  const { ethers } = connection;

  const ADDR = process.env.CONTRACT!;
  const c = await ethers.getContractAt("VotingSimple", ADDR);

  const [yes, no] = await c.tally();
  console.log("Tally:", { yes: Number(yes), no: Number(no) });
}

main().catch((e) => { console.error(e); process.exit(1); });
