import hre from "hardhat";

async function main() {
  const connection = await hre.network.connect();
  const { ethers } = connection;

  const ADDR = process.env.CONTRACT!;         // export CONTRACT=0x...
  const h = (s: string) => ethers.keccak256(ethers.toUtf8Bytes(s));

  const c = await ethers.getContractAt("VotingSimple", ADDR);
  const voterHash = h(process.env.VOTER!);    // ej: "dni|fecha|secreto"

  const tx = await c.registerVoter(voterHash);
  await tx.wait();
  console.log("Registered:", voterHash);
}

main().catch((e) => { console.error(e); process.exit(1); });
