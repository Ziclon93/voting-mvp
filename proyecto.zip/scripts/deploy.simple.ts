// scripts/deploy.simple.ts
import hre from "hardhat";

async function main() {
  const connection = await hre.network.connect();
  const [deployer] = await connection.ethers.getSigners();
  console.log("Deployer:", await deployer.getAddress());

  const F = await connection.ethers.getContractFactory("VotingSimple");
  const c = await F.deploy();
  await c.waitForDeployment();

  console.log("VotingSimple:", await c.getAddress());
}

main().catch((e) => { console.error(e); process.exit(1); });
